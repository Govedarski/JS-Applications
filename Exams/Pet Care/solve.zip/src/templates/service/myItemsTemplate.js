const memeCardTemplate = (ctx, data) => ctx.lit.html`

`;

const noContentTemplate = (ctx) => ctx.lit.html`
`;

export const listContentTemplate = (ctx, data) => ctx.lit.html`

`;


export const myItemsTemplate = (ctx, userData, itemsData) => ctx.lit.html`

`;