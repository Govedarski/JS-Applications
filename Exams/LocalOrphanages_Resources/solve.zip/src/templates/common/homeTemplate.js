export const homeTemplate = (ctx) => ctx.lit.html`
home page
`;