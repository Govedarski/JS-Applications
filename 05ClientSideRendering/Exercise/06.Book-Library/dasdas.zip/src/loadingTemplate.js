import {html} from '../../../../node_modules/lit-html/lit-html.js';


export const loadingTemplate = () => html`<tr>
    <td>Loading...</td>
    <td>Loading...</td>
    <td>Loading...</td>
</tr>`
